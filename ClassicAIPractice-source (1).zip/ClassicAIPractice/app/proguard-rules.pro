# Default R8 rules from proguard-android-optimize.txt are applied.
# No additional keep rules are required for this app.
