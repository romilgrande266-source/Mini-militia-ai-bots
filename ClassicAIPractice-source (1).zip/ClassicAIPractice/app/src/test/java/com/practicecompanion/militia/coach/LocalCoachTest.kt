package com.practicecompanion.militia.coach

import com.practicecompanion.militia.data.Session
import com.practicecompanion.militia.data.SessionType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LocalCoachTest {
    private val now = 10_000_000_000L

    private fun aim(hits: Int, misses: Int) =
        Session(SessionType.AIM, timestamp = now, durationSec = 30, hits = hits, misses = misses)

    private fun reaction(avgMs: Int) =
        Session(SessionType.REACTION, timestamp = now, durationSec = 5, hits = 5, misses = 0,
            avgReactionMs = avgMs, bestReactionMs = avgMs - 10)

    private fun movement(daysAgo: Int) =
        Session(SessionType.MOVEMENT, timestamp = now - daysAgo * 24L * 60 * 60 * 1000, durationSec = 60, completions = 1)

    @Test
    fun emptyHistoryGivesBaseline() {
        val result = LocalCoach.recommend(emptyList(), now)
        assertEquals("Start with a baseline", result.single().title)
    }

    @Test
    fun lowAimAccuracySuggestsSlowingDown() {
        val result = LocalCoach.recommend(listOf(aim(3, 7), aim(4, 6), aim(5, 5), movement(0)), now)
        assertTrue(result.any { it.title == "Slow down your aim" })
    }

    @Test
    fun highAimAccuracySuggestsHigherChallenge() {
        val result = LocalCoach.recommend(listOf(aim(9, 1), aim(9, 1), aim(10, 0), movement(0)), now)
        assertTrue(result.any { it.title == "Raise the challenge" })
    }

    @Test
    fun slowReactionSuggestsReactionWork() {
        val result = LocalCoach.recommend(listOf(reaction(350), movement(0)), now)
        assertTrue(result.any { it.title == "Work on reaction time" })
    }

    @Test
    fun noRecentMovementSuggestsMovementDrill() {
        val result = LocalCoach.recommend(listOf(aim(5, 5), movement(30)), now)
        assertTrue(result.any { it.title == "Add a movement drill" })
    }

    @Test
    fun resultsAreCappedAtThree() {
        val result = LocalCoach.recommend(listOf(aim(1, 9), reaction(400)), now)
        assertTrue(result.size <= 3)
    }
}
