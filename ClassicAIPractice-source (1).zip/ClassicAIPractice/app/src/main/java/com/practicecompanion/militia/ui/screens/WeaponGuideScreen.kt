package com.practicecompanion.militia.ui.screens

import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import com.practicecompanion.militia.ui.components.AppBanner
import com.practicecompanion.militia.ui.components.ScreenScaffold
import com.practicecompanion.militia.ui.components.SectionCard

private data class Guide(val title: String, val body: String)

private val guides = listOf(
    Guide(
        "Match the weapon to the distance",
        "Close-range fights favor fast, wide-spread weapons. Longer range favors slower, more precise ones. " +
            "Read each weapon's in-game description the first time you unlock it.",
    ),
    Guide(
        "Control your bursts",
        "Fire in short bursts and let your aim settle between them. Holding fire at long range usually " +
            "wastes ammo and spreads your shots.",
    ),
    Guide(
        "Reload when it is safe",
        "Reload behind cover or right after a kill, not in the middle of an open exchange. " +
            "Check your ammo before you commit to a fight.",
    ),
    Guide(
        "Switch before you run dry",
        "Change to your backup weapon before the magazine is empty, so you are not reloading while an " +
            "enemy is in view.",
    ),
    Guide(
        "Time your throwables",
        "Use grenades to clear a choke point or a corner you cannot see around. Throw before you push, " +
            "not after you have already committed.",
    ),
    Guide(
        "Learn weapons in the game itself",
        "Use the game's own practice or solo options to learn how each weapon behaves. This app does not " +
            "track the game's current weapon stats.",
    ),
)

@Composable
fun WeaponGuideScreen(onBack: () -> Unit) {
    val expanded = remember { mutableStateListOf<String>() }

    ScreenScaffold(title = "Weapon Guides", onBack = onBack) {
        AppBanner(
            "General tactics written for this app. They are not checked against the game's " +
                "current weapon list or stats."
        )

        guides.forEach { guide ->
            val isOpen = guide.title in expanded
            SectionCard(
                title = guide.title,
                subtitle = if (isOpen) guide.body else "Tap to read",
            ) {
                if (isOpen) expanded.remove(guide.title) else expanded.add(guide.title)
            }
        }
    }
}
