package com.practicecompanion.militia.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.practicecompanion.militia.data.PracticeRepository
import com.practicecompanion.militia.data.Session
import com.practicecompanion.militia.data.SessionType
import com.practicecompanion.militia.ui.components.AppBanner
import com.practicecompanion.militia.ui.components.ScreenScaffold
import com.practicecompanion.militia.ui.components.SectionCard
import com.practicecompanion.militia.ui.theme.MilAmber
import com.practicecompanion.militia.ui.theme.MilOlive
import com.practicecompanion.militia.ui.theme.MilSurface
import com.practicecompanion.militia.ui.theme.MilText
import kotlinx.coroutines.delay

private data class Drill(val title: String, val suggestedMinutes: Int, val instructions: String)

private val drills = listOf(
    Drill(
        title = "Strafe and hold",
        suggestedMinutes = 1,
        instructions = "Move left and right in short bursts of about one second, keeping one fixed landmark in view. " +
            "Stop completely between bursts and check where you stopped. Vary the speed.",
    ),
    Drill(
        title = "Jump timing ladder",
        suggestedMinutes = 2,
        instructions = "Jump onto platforms of increasing height. Start with the lowest one, and move up only " +
            "after each jump lands cleanly. Notice how many attempts each height takes.",
    ),
    Drill(
        title = "Jetpack control",
        suggestedMinutes = 1,
        instructions = "Use short jetpack bursts to hold one height for three seconds, then climb and descend " +
            "in small controlled steps. Focus on precision rather than top speed.",
    ),
    Drill(
        title = "Route planning",
        suggestedMinutes = 1,
        instructions = "Before moving, pick a route between three points on the map and say it out loud. " +
            "Play it, then repeat with a different route and compare the times.",
    ),
    Drill(
        title = "Cover and peek",
        suggestedMinutes = 1,
        instructions = "Stand behind cover, peek for about one second, then retreat. Keep each exposure as " +
            "short as possible and vary the timing so it is not predictable.",
    ),
)

@Composable
fun MovementScreen(repo: PracticeRepository, onBack: () -> Unit) {
    var selected by remember { mutableStateOf<Drill?>(null) }
    var running by remember { mutableStateOf(false) }
    var elapsed by remember { mutableIntStateOf(0) }

    LaunchedEffect(running) {
        while (running) {
            delay(1000L)
            elapsed += 1
        }
    }

    ScreenScaffold(title = "Movement Training", onBack = onBack) {
        AppBanner(
            "Self-reported. This app cannot see your in-game movement. " +
                "Log a drill only after you actually complete it."
        )

        drills.forEach { drill ->
            SectionCard(
                title = drill.title,
                subtitle = "About ${drill.suggestedMinutes} min. Tap to open.",
            ) {
                selected = drill
                running = false
                elapsed = 0
            }
        }

        selected?.let { drill ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MilSurface),
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = drill.title,
                        style = MaterialTheme.typography.titleMedium,
                        color = MilOlive,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        text = drill.instructions,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MilText,
                    )
                    Text(
                        text = formatTime(elapsed),
                        style = MaterialTheme.typography.headlineMedium,
                        color = MilAmber,
                        fontWeight = FontWeight.Bold,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(
                            onClick = { running = !running },
                            modifier = Modifier.weight(1f),
                        ) {
                            Text(if (running) "Pause" else "Start timer")
                        }
                        OutlinedButton(
                            onClick = {
                                repo.addSession(
                                    Session(
                                        type = SessionType.MOVEMENT,
                                        timestamp = System.currentTimeMillis(),
                                        durationSec = elapsed.coerceAtLeast(1),
                                        completions = 1,
                                    )
                                )
                                running = false
                                elapsed = 0
                            },
                            enabled = elapsed > 0,
                            modifier = Modifier.weight(1f),
                        ) {
                            Text("Log completion")
                        }
                    }
                }
            }
        }
    }
}

private fun formatTime(totalSeconds: Int): String =
    "%d:%02d".format(totalSeconds / 60, totalSeconds % 60)
