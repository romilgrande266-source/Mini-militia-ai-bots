package com.practicecompanion.militia.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val MilBg = Color(0xFF0B0F0C)
val MilSurface = Color(0xFF151C17)
val MilSurfaceAlt = Color(0xFF1F2822)
val MilOlive = Color(0xFF9CC26B)
val MilAmber = Color(0xFFE0A526)
val MilRed = Color(0xFFD9534F)
val MilGreen = Color(0xFF5CB85C)
val MilText = Color(0xFFE6EDE3)
val MilMuted = Color(0xFF9AA79C)

private val MilitaryDarkScheme = darkColorScheme(
    primary = MilOlive,
    onPrimary = MilBg,
    secondary = MilAmber,
    onSecondary = MilBg,
    background = MilBg,
    onBackground = MilText,
    surface = MilSurface,
    onSurface = MilText,
    surfaceVariant = MilSurfaceAlt,
    onSurfaceVariant = MilMuted,
    error = MilRed,
)

@Composable
fun PracticeTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = MilitaryDarkScheme, content = content)
}
