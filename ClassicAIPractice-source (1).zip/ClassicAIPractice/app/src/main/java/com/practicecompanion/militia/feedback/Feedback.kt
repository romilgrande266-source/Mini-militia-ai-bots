package com.practicecompanion.militia.feedback

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator

/** Sound and haptic cues. Each channel is controlled by the user's Settings toggles. */
object Feedback {
    private var tone: ToneGenerator? = null

    fun hit(context: Context, sound: Boolean, vibration: Boolean) {
        signal(context, sound, vibration, ToneGenerator.TONE_PROP_ACK, 20L)
    }

    fun miss(context: Context, sound: Boolean, vibration: Boolean) {
        signal(context, sound, vibration, ToneGenerator.TONE_PROP_NACK, 60L)
    }

    private fun signal(context: Context, sound: Boolean, vibration: Boolean, toneId: Int, vibrateMs: Long) {
        if (sound) {
            runCatching {
                val generator = tone ?: ToneGenerator(AudioManager.STREAM_NOTIFICATION, 60).also { tone = it }
                generator.startTone(toneId, 120)
            }
        }
        if (vibration) vibrate(context, vibrateMs)
    }

    @Suppress("DEPRECATION")
    private fun vibrate(context: Context, ms: Long) {
        val vibrator = context.getSystemService(Vibrator::class.java) ?: return
        if (!vibrator.hasVibrator()) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            vibrator.vibrate(ms)
        }
    }
}
