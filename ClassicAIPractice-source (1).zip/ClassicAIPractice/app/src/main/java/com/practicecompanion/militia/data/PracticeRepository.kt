package com.practicecompanion.militia.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

data class AppSettings(
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val language: String = "en",
    val gamePackage: String = "",
)

/**
 * Local-only storage backed by SharedPreferences (JSON for history).
 * Nothing here touches the network, and no account is required.
 */
class PracticeRepository(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    var settings: AppSettings by mutableStateOf(readSettings())
        private set

    var history: List<Session> by mutableStateOf(readHistory())
        private set

    fun updateSettings(newSettings: AppSettings) {
        settings = newSettings
        prefs.edit()
            .putBoolean(KEY_SOUND, newSettings.soundEnabled)
            .putBoolean(KEY_VIBRATION, newSettings.vibrationEnabled)
            .putString(KEY_LANGUAGE, newSettings.language)
            .putString(KEY_GAME_PACKAGE, newSettings.gamePackage)
            .apply()
    }

    /** Adds a session to the top of the history (newest first), capped at MAX_HISTORY. */
    fun addSession(session: Session) {
        history = (listOf(session) + history).take(MAX_HISTORY)
        persistHistory()
    }

    fun clearHistory() {
        history = emptyList()
        persistHistory()
    }

    fun resetAll() {
        prefs.edit().clear().apply()
        settings = AppSettings()
        history = emptyList()
    }

    private fun readSettings() = AppSettings(
        soundEnabled = prefs.getBoolean(KEY_SOUND, true),
        vibrationEnabled = prefs.getBoolean(KEY_VIBRATION, true),
        language = prefs.getString(KEY_LANGUAGE, "en") ?: "en",
        gamePackage = prefs.getString(KEY_GAME_PACKAGE, "") ?: "",
    )

    private fun readHistory(): List<Session> {
        val raw = prefs.getString(KEY_HISTORY, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            List(array.length()) { index -> array.getJSONObject(index).toSession() }
        } catch (e: Exception) {
            // Corrupted data: start with an empty history instead of crashing.
            emptyList()
        }
    }

    private fun persistHistory() {
        val array = JSONArray()
        history.forEach { array.put(it.toJson()) }
        prefs.edit().putString(KEY_HISTORY, array.toString()).apply()
    }

    private fun Session.toJson(): JSONObject = JSONObject().apply {
        put("type", type.name)
        put("ts", timestamp)
        put("dur", durationSec)
        put("hits", hits)
        put("misses", misses)
        avgReactionMs?.let { put("avg", it) }
        bestReactionMs?.let { put("best", it) }
        put("completions", completions)
    }

    private fun JSONObject.toSession(): Session = Session(
        type = SessionType.valueOf(getString("type")),
        timestamp = getLong("ts"),
        durationSec = getInt("dur"),
        hits = optInt("hits", 0),
        misses = optInt("misses", 0),
        avgReactionMs = if (has("avg")) getInt("avg") else null,
        bestReactionMs = if (has("best")) getInt("best") else null,
        completions = optInt("completions", 0),
    )

    companion object {
        private const val PREFS = "practice_prefs"
        private const val KEY_SOUND = "sound"
        private const val KEY_VIBRATION = "vibration"
        private const val KEY_LANGUAGE = "language"
        private const val KEY_GAME_PACKAGE = "game_package"
        private const val KEY_HISTORY = "history"
        private const val MAX_HISTORY = 500
    }
}
