package com.practicecompanion.militia.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.practicecompanion.militia.data.PracticeRepository
import com.practicecompanion.militia.data.Session
import com.practicecompanion.militia.data.SessionType
import com.practicecompanion.militia.ui.components.AppBanner
import com.practicecompanion.militia.ui.components.ScreenScaffold
import com.practicecompanion.militia.ui.components.StatTile
import com.practicecompanion.militia.ui.theme.MilAmber
import com.practicecompanion.militia.ui.theme.MilMuted
import com.practicecompanion.militia.ui.theme.MilOlive
import com.practicecompanion.militia.ui.theme.MilSurface
import com.practicecompanion.militia.ui.theme.MilText
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun StatsScreen(repo: PracticeRepository, onBack: () -> Unit) {
    val history = repo.history
    var confirmClear by remember { mutableStateOf(false) }
    val dateFormat = remember { SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()) }

    val aimAccuracies = history.mapNotNull { it.accuracy }.take(10)
    val aimChart = aimAccuracies.reversed().map { it * 100f }
    val reactionChart = history
        .mapNotNull { it.avgReactionMs?.toFloat() }
        .take(10)
        .reversed()
    val bestReaction = history.mapNotNull { it.bestReactionMs }.minOrNull()
    val totalMinutes = history.sumOf { it.durationSec } / 60

    ScreenScaffold(title = "Statistics", onBack = onBack) {
        AppBanner("Statistics cover only sessions saved on this device, including this app's own drills.")

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile(label = "Sessions", value = history.size.toString(), modifier = Modifier.weight(1f))
            StatTile(label = "Minutes practiced", value = totalMinutes.toString(), modifier = Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile(
                label = "Avg aim accuracy (last 10)",
                value = if (aimAccuracies.isEmpty()) "-" else "${(aimAccuracies.average() * 100).toInt()}%",
                modifier = Modifier.weight(1f),
            )
            StatTile(
                label = "Best reaction",
                value = bestReaction?.let { "$it ms" } ?: "-",
                modifier = Modifier.weight(1f),
            )
        }

        BarChartCard(
            title = "Aim accuracy, last 10 sessions",
            values = aimChart,
            unit = "%",
        )
        BarChartCard(
            title = "Average reaction, last 10 tests",
            values = reactionChart,
            unit = " ms",
        )

        Text(
            text = "History",
            style = MaterialTheme.typography.titleMedium,
            color = MilOlive,
            fontWeight = FontWeight.Bold,
        )
        if (history.isEmpty()) {
            Text("No sessions yet. Try Aim or Reaction training to start your history.", color = MilMuted)
        }
        history.forEach { session ->
            HistoryRow(session, dateFormat)
        }

        Button(
            onClick = { confirmClear = true },
            enabled = history.isNotEmpty(),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text("Clear history")
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear practice history?") },
            text = { Text("This removes all saved sessions from this device. It cannot be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    repo.clearHistory()
                    confirmClear = false
                }) {
                    Text("Clear")
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmClear = false }) {
                    Text("Cancel")
                }
            },
        )
    }
}

@Composable
private fun BarChartCard(title: String, values: List<Float>, unit: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MilSurface),
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(text = title, style = MaterialTheme.typography.titleSmall, color = MilOlive)
            if (values.isEmpty()) {
                Text("No data yet.", style = MaterialTheme.typography.bodySmall, color = MilMuted)
            } else {
                val maxValue = values.maxOrNull()?.coerceAtLeast(1f) ?: 1f
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                        .padding(top = 8.dp),
                ) {
                    val slot = size.width / values.size
                    val barWidth = slot * 0.6f
                    values.forEachIndexed { index, value ->
                        val barHeight = size.height * (value / maxValue)
                        drawRect(
                            color = MilAmber,
                            topLeft = Offset(index * slot + (slot - barWidth) / 2f, size.height - barHeight),
                            size = Size(barWidth, barHeight),
                        )
                    }
                }
                Text(
                    text = "Latest: ${values.last().toInt()}$unit (oldest on left)",
                    style = MaterialTheme.typography.labelSmall,
                    color = MilMuted,
                )
            }
        }
    }
}

@Composable
private fun HistoryRow(session: Session, dateFormat: SimpleDateFormat) {
    val title = when (session.type) {
        SessionType.AIM -> "Aim"
        SessionType.REACTION -> "Reaction"
        SessionType.MOVEMENT -> "Movement"
    }
    val detail = when (session.type) {
        SessionType.AIM -> {
            val acc = session.accuracy?.let { "${(it * 100).toInt()}%" } ?: "-"
            "Hits ${session.hits}, misses ${session.misses}, accuracy $acc"
        }
        SessionType.REACTION -> {
            "Avg ${session.avgReactionMs ?: "-"} ms, best ${session.bestReactionMs ?: "-"} ms, " +
                "false starts ${session.misses}"
        }
        SessionType.MOVEMENT -> "Completed ${session.completions}, time ${session.durationSec}s"
    }
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MilSurface),
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(
                text = "$title  |  ${dateFormat.format(Date(session.timestamp))}",
                style = MaterialTheme.typography.bodyMedium,
                color = MilText,
                fontWeight = FontWeight.SemiBold,
            )
            Text(text = detail, style = MaterialTheme.typography.bodySmall, color = MilMuted)
        }
    }
}
