package com.practicecompanion.militia.ui.screens

import android.content.ActivityNotFoundException
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.practicecompanion.militia.data.PracticeRepository
import com.practicecompanion.militia.game.GameLauncher
import com.practicecompanion.militia.game.GameStatus
import com.practicecompanion.militia.ui.components.AppBanner
import com.practicecompanion.militia.ui.components.ScreenScaffold
import com.practicecompanion.militia.ui.theme.MilAmber
import com.practicecompanion.militia.ui.theme.MilMuted
import com.practicecompanion.militia.ui.theme.MilOlive
import com.practicecompanion.militia.ui.theme.MilSurface
import com.practicecompanion.militia.ui.theme.MilText

@Composable
fun ConnectionScreen(repo: PracticeRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    var input by remember { mutableStateOf(repo.settings.gamePackage) }
    var status by remember {
        mutableStateOf<GameStatus?>(
            repo.settings.gamePackage.takeIf { it.isNotBlank() }?.let { GameLauncher.check(context, it) }
        )
    }
    var launchMessage by remember { mutableStateOf<String?>(null) }

    ScreenScaffold(title = "Game Connection", onBack = onBack) {
        AppBanner(
            "This screen only checks that the game is installed and opens it. The app cannot read match " +
                "data, control the game, or add bots. No official game integration exists in this version."
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MilSurface),
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "Setup",
                    style = MaterialTheme.typography.titleSmall,
                    color = MilOlive,
                    fontWeight = FontWeight.Bold,
                )
                Text("1. Install Mini Militia Classic from its official store listing.", color = MilText)
                Text(
                    "2. Find its package name (a dotted ID such as com.company.app) using an app-info or " +
                        "package-viewer tool.",
                    color = MilText,
                )
                Text(
                    "3. Enter it below and tap Check. This app does not verify package names or game versions.",
                    color = MilText,
                )
            }
        }

        OutlinedTextField(
            value = input,
            onValueChange = { input = it },
            label = { Text("Package name") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(
                onClick = {
                    repo.updateSettings(repo.settings.copy(gamePackage = input.trim()))
                    status = GameLauncher.check(context, input)
                    launchMessage = null
                },
                modifier = Modifier.weight(1f),
            ) {
                Text("Check")
            }
            Button(
                onClick = {
                    val intent = GameLauncher.launchIntent(context, input)
                    launchMessage = if (intent == null) {
                        "Cannot open this app. Check that it is installed."
                    } else {
                        try {
                            context.startActivity(intent)
                            null
                        } catch (e: ActivityNotFoundException) {
                            "Could not open the app."
                        }
                    }
                },
                enabled = status?.installed == true,
                modifier = Modifier.weight(1f),
            ) {
                Text("Open game")
            }
        }

        status?.let { current ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MilSurface),
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(current.message, color = MilText, fontWeight = FontWeight.SemiBold)
                    current.appLabel?.let { Text("App name: $it", color = MilMuted) }
                    current.versionName?.let { Text("Version: $it", color = MilMuted) }
                }
            }
        }

        launchMessage?.let { Text(it, color = MilAmber) }
    }
}
