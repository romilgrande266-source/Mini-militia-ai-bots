package com.practicecompanion.militia.game

import android.content.Context
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build

data class GameStatus(
    val installed: Boolean,
    val versionName: String?,
    val appLabel: String?,
    val message: String,
)

/**
 * Checks whether a user-chosen package is installed and opens it.
 * This only uses the public PackageManager and launch intent. It does not read,
 * inject into, or control the game.
 */
object GameLauncher {
    private val packagePattern = Regex("^[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z][a-zA-Z0-9_]*)+$")

    fun isValidPackageName(name: String): Boolean = packagePattern.matches(name.trim())

    fun check(context: Context, packageName: String): GameStatus {
        val pkg = packageName.trim()
        if (pkg.isEmpty()) {
            return GameStatus(false, null, null, "Enter the package name of the installed game.")
        }
        if (!isValidPackageName(pkg)) {
            return GameStatus(false, null, null, "That does not look like a package name. Example: com.company.game")
        }
        val pm = context.packageManager
        return try {
            val info = packageInfo(pm, pkg)
            GameStatus(
                installed = true,
                versionName = info.versionName,
                appLabel = info.applicationInfo?.loadLabel(pm)?.toString(),
                message = "Installed. This app cannot verify version compatibility.",
            )
        } catch (e: PackageManager.NameNotFoundException) {
            GameStatus(false, null, null, "Not installed, or the package name is wrong.")
        }
    }

    fun launchIntent(context: Context, packageName: String): Intent? =
        context.packageManager.getLaunchIntentForPackage(packageName.trim())
            ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    @Suppress("DEPRECATION")
    private fun packageInfo(pm: PackageManager, pkg: String): PackageInfo =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0))
        } else {
            pm.getPackageInfo(pkg, 0)
        }
}
