package com.practicecompanion.militia.coach

import com.practicecompanion.militia.data.Session
import com.practicecompanion.militia.data.SessionType

data class Recommendation(
    val title: String,
    val detail: String,
    val focus: SessionType?,
)

/**
 * Rule-based training suggestions computed only from the user's local history.
 * This is fixed, readable logic, not a machine-learning model, and it has no
 * connection to Mini Militia Classic or its AI.
 */
object LocalCoach {
    private const val DAY_MS = 24L * 60 * 60 * 1000

    fun recommend(history: List<Session>, now: Long = System.currentTimeMillis()): List<Recommendation> {
        if (history.isEmpty()) {
            return listOf(
                Recommendation(
                    title = "Start with a baseline",
                    detail = "Run one 30-second Aim session and one Reaction test to record starting numbers.",
                    focus = null,
                )
            )
        }

        val result = mutableListOf<Recommendation>()

        // Rules 1 and 2: aim accuracy over the last five aim sessions.
        val recentAim = history.filter { it.accuracy != null }.take(5)
        if (recentAim.isNotEmpty()) {
            val avgAccuracy = recentAim.mapNotNull { it.accuracy }.average()
            if (avgAccuracy < 0.6) {
                result.add(
                    Recommendation(
                        title = "Slow down your aim",
                        detail = "Your last ${recentAim.size} aim sessions averaged ${percent(avgAccuracy)} accuracy. " +
                            "Try Easy targets and focus on landing shots before speeding up.",
                        focus = SessionType.AIM,
                    )
                )
            } else if (avgAccuracy >= 0.85 && recentAim.size >= 3) {
                result.add(
                    Recommendation(
                        title = "Raise the challenge",
                        detail = "Accuracy is ${percent(avgAccuracy)} over your last ${recentAim.size} sessions. " +
                            "Move up to Hard targets.",
                        focus = SessionType.AIM,
                    )
                )
            }
        }

        // Rule 3: reaction average over the last five reaction tests.
        val recentReaction = history
            .filter { it.type == SessionType.REACTION && it.avgReactionMs != null }
            .take(5)
        if (recentReaction.isNotEmpty()) {
            val avgMs = recentReaction.mapNotNull { it.avgReactionMs }.average()
            if (avgMs > 300) {
                result.add(
                    Recommendation(
                        title = "Work on reaction time",
                        detail = "Your recent reaction average is ${avgMs.toInt()} ms. " +
                            "Short reaction tests before a play session can help.",
                        focus = SessionType.REACTION,
                    )
                )
            }
        }

        // Rule 4: no movement drills in the last seven days.
        val movedRecently = history.any {
            it.type == SessionType.MOVEMENT && now - it.timestamp <= 7 * DAY_MS
        }
        if (!movedRecently) {
            result.add(
                Recommendation(
                    title = "Add a movement drill",
                    detail = "No movement drills logged in the last 7 days. Try one from Movement Training.",
                    focus = SessionType.MOVEMENT,
                )
            )
        }

        if (result.isEmpty()) {
            result.add(
                Recommendation(
                    title = "Keep your routine",
                    detail = "Your recent numbers look steady. Keep logging sessions to see trends.",
                    focus = null,
                )
            )
        }
        return result.take(3)
    }

    private fun percent(value: Double): String = "${(value * 100).toInt()}%"
}
