package com.practicecompanion.militia.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.practicecompanion.militia.BuildConfig
import com.practicecompanion.militia.data.PracticeRepository
import com.practicecompanion.militia.ui.components.ScreenScaffold
import com.practicecompanion.militia.ui.theme.MilMuted
import com.practicecompanion.militia.ui.theme.MilOlive
import com.practicecompanion.militia.ui.theme.MilRed
import com.practicecompanion.militia.ui.theme.MilSurface
import com.practicecompanion.militia.ui.theme.MilText

@Composable
fun SettingsScreen(repo: PracticeRepository, onBack: () -> Unit) {
    val current = repo.settings
    var confirmReset by remember { mutableStateOf(false) }

    ScreenScaffold(title = "Settings", onBack = onBack) {
        SettingSwitch(
            label = "Sound feedback",
            checked = current.soundEnabled,
            onChange = { repo.updateSettings(current.copy(soundEnabled = it)) },
        )
        SettingSwitch(
            label = "Vibration feedback",
            checked = current.vibrationEnabled,
            onChange = { repo.updateSettings(current.copy(vibrationEnabled = it)) },
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MilSurface),
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Language", style = MaterialTheme.typography.titleSmall, color = MilOlive, fontWeight = FontWeight.Bold)
                Text("English (the only language included in this version)", color = MilText)
                Text(
                    "Other translations are not yet included, so this app does not offer a language switch.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MilMuted,
                )
            }
        }

        Button(
            onClick = { repo.clearHistory() },
            enabled = repo.history.isNotEmpty(),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text("Clear practice history")
        }
        Button(
            onClick = { confirmReset = true },
            colors = ButtonDefaults.buttonColors(containerColor = MilRed),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text("Reset all app data")
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MilSurface),
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("About", style = MaterialTheme.typography.titleSmall, color = MilOlive, fontWeight = FontWeight.Bold)
                Text("Version ${BuildConfig.VERSION_NAME}", color = MilText)
                Text(
                    "Unofficial companion app. Not affiliated with the makers of Mini Militia Classic.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MilMuted,
                )
                Text(
                    "Permissions: vibration for haptic cues, and package visibility to check the game you choose. " +
                        "No internet permission is requested. All data stays on this device.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MilMuted,
                )
            }
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Reset all app data?") },
            text = { Text("This clears your history, settings, and saved game package name.") },
            confirmButton = {
                TextButton(onClick = {
                    repo.resetAll()
                    confirmReset = false
                }) {
                    Text("Reset")
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmReset = false }) {
                    Text("Cancel")
                }
            },
        )
    }
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MilSurface),
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(label, color = MilText, modifier = Modifier.weight(1f))
            Switch(checked = checked, onCheckedChange = onChange)
        }
    }
}
