package com.practicecompanion.militia.data

enum class SessionType { AIM, REACTION, MOVEMENT }

/**
 * One saved practice session. Kept free of Android imports so it can be unit-tested on the JVM.
 *
 * AIM:      hits = targets hit, misses = missed clicks.
 * REACTION: hits = rounds completed, misses = false starts, avg/best in milliseconds.
 * MOVEMENT: completions = drills the user reported finishing, durationSec = time spent.
 */
data class Session(
    val type: SessionType,
    val timestamp: Long,
    val durationSec: Int,
    val hits: Int = 0,
    val misses: Int = 0,
    val avgReactionMs: Int? = null,
    val bestReactionMs: Int? = null,
    val completions: Int = 0,
) {
    val accuracy: Float?
        get() = if (type == SessionType.AIM && hits + misses > 0) {
            hits.toFloat() / (hits + misses)
        } else {
            null
        }
}
