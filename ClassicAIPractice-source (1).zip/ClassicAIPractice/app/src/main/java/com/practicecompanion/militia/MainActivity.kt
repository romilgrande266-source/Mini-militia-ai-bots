package com.practicecompanion.militia

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.practicecompanion.militia.data.PracticeRepository
import com.practicecompanion.militia.ui.screens.AimTrainingScreen
import com.practicecompanion.militia.ui.screens.ConnectionScreen
import com.practicecompanion.militia.ui.screens.DashboardScreen
import com.practicecompanion.militia.ui.screens.MovementScreen
import com.practicecompanion.militia.ui.screens.ReactionScreen
import com.practicecompanion.militia.ui.screens.SettingsScreen
import com.practicecompanion.militia.ui.screens.StatsScreen
import com.practicecompanion.militia.ui.screens.WeaponGuideScreen
import com.practicecompanion.militia.ui.theme.PracticeTheme

object Routes {
    const val DASHBOARD = "dashboard"
    const val AIM = "aim"
    const val REACTION = "reaction"
    const val MOVEMENT = "movement"
    const val WEAPONS = "weapons"
    const val STATS = "stats"
    const val CONNECTION = "connection"
    const val SETTINGS = "settings"
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PracticeTheme {
                val repo = remember { PracticeRepository(applicationContext) }
                AppNavHost(repo)
            }
        }
    }
}

@Composable
fun AppNavHost(repo: PracticeRepository) {
    val navController = rememberNavController()
    val onBack: () -> Unit = { navController.popBackStack() }

    NavHost(navController = navController, startDestination = Routes.DASHBOARD) {
        composable(Routes.DASHBOARD) {
            DashboardScreen(repo) { route -> navController.navigate(route) }
        }
        composable(Routes.AIM) { AimTrainingScreen(repo, onBack) }
        composable(Routes.REACTION) { ReactionScreen(repo, onBack) }
        composable(Routes.MOVEMENT) { MovementScreen(repo, onBack) }
        composable(Routes.WEAPONS) { WeaponGuideScreen(onBack) }
        composable(Routes.STATS) { StatsScreen(repo, onBack) }
        composable(Routes.CONNECTION) { ConnectionScreen(repo, onBack) }
        composable(Routes.SETTINGS) { SettingsScreen(repo, onBack) }
    }
}
