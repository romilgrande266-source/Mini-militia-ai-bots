package com.practicecompanion.militia.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import com.practicecompanion.militia.data.PracticeRepository
import com.practicecompanion.militia.data.Session
import com.practicecompanion.militia.data.SessionType
import com.practicecompanion.militia.feedback.Feedback
import com.practicecompanion.militia.ui.components.AppBanner
import com.practicecompanion.militia.ui.components.ScreenScaffold
import com.practicecompanion.militia.ui.components.StatTile
import com.practicecompanion.militia.ui.theme.MilAmber
import com.practicecompanion.militia.ui.theme.MilBg
import com.practicecompanion.militia.ui.theme.MilMuted
import com.practicecompanion.militia.ui.theme.MilSurface
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

private const val AIM_SECONDS = 30

enum class AimDifficulty(val label: String, val radiusDp: Float, val speedDp: Float, val turnSeconds: Float) {
    EASY("Easy", 56f, 60f, 2.5f),
    NORMAL("Normal", 40f, 130f, 1.6f),
    HARD("Hard", 28f, 200f, 0.9f),
}

@Composable
fun AimTrainingScreen(repo: PracticeRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val density = LocalDensity.current.density
    val settings = repo.settings

    var difficulty by remember { mutableStateOf(AimDifficulty.NORMAL) }
    var running by remember { mutableStateOf(false) }
    var remaining by remember { mutableIntStateOf(AIM_SECONDS) }
    var hits by remember { mutableIntStateOf(0) }
    var misses by remember { mutableIntStateOf(0) }
    var areaW by remember { mutableFloatStateOf(0f) }
    var areaH by remember { mutableFloatStateOf(0f) }
    var targetX by remember { mutableFloatStateOf(0f) }
    var targetY by remember { mutableFloatStateOf(0f) }
    var velX by remember { mutableFloatStateOf(0f) }
    var velY by remember { mutableFloatStateOf(0f) }

    val radiusPx = difficulty.radiusDp * density
    val speedPx = difficulty.speedDp * density

    fun randomDirectionVelocity() {
        val angle = Random.nextDouble(0.0, 2 * PI)
        velX = (cos(angle) * speedPx).toFloat()
        velY = (sin(angle) * speedPx).toFloat()
    }

    fun placeTargetRandomly() {
        val r = radiusPx
        if (areaW <= 2 * r || areaH <= 2 * r) return
        targetX = r + Random.nextFloat() * (areaW - 2 * r)
        targetY = r + Random.nextFloat() * (areaH - 2 * r)
        randomDirectionVelocity()
    }

    fun finishSession() {
        if (!running) return
        running = false
        if (hits + misses > 0) {
            repo.addSession(
                Session(
                    type = SessionType.AIM,
                    timestamp = System.currentTimeMillis(),
                    durationSec = AIM_SECONDS - remaining,
                    hits = hits,
                    misses = misses,
                )
            )
        }
    }

    // Countdown. Changing `running` cancels and restarts this effect.
    LaunchedEffect(running) {
        if (!running) return@LaunchedEffect
        while (remaining > 0) {
            delay(1000L)
            remaining -= 1
        }
        finishSession()
    }

    // Frame loop: moves the target, bounces it off the edges, and re-aims it periodically.
    LaunchedEffect(running) {
        if (!running) return@LaunchedEffect
        var lastFrame = -1L
        var sinceTurn = 0f
        var nextTurn = difficulty.turnSeconds
        while (true) {
            withFrameNanos { now ->
                if (lastFrame >= 0L && areaW > 0f) {
                    val dt = (now - lastFrame) / 1_000_000_000f
                    targetX += velX * dt
                    targetY += velY * dt
                    val r = radiusPx
                    if (targetX - r < 0f) { targetX = r; velX = abs(velX) }
                    if (targetX + r > areaW) { targetX = areaW - r; velX = -abs(velX) }
                    if (targetY - r < 0f) { targetY = r; velY = abs(velY) }
                    if (targetY + r > areaH) { targetY = areaH - r; velY = -abs(velY) }

                    sinceTurn += dt
                    if (sinceTurn >= nextTurn) {
                        sinceTurn = 0f
                        nextTurn = difficulty.turnSeconds * (0.7f + Random.nextFloat() * 0.6f)
                        randomDirectionVelocity()
                    }
                }
                lastFrame = now
            }
        }
    }

    ScreenScaffold(title = "Aim Training", onBack = onBack, scrollable = false) {
        AppBanner(
            "Targets are generated by this app for practice. They are not part of Mini Militia Classic."
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AimDifficulty.entries.forEach { option ->
                FilterChip(
                    selected = difficulty == option,
                    onClick = { if (!running) difficulty = option },
                    label = { Text(option.label) },
                    enabled = !running,
                )
            }
        }

        val attempts = hits + misses
        val accuracyText = if (attempts > 0) "${hits * 100 / attempts}%" else "-"
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile(label = "Hits / misses", value = "$hits / $misses", modifier = Modifier.weight(1f))
            StatTile(label = "Accuracy", value = accuracyText, modifier = Modifier.weight(1f))
            StatTile(label = "Time left", value = "${remaining}s", modifier = Modifier.weight(1f))
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(MilSurface)
                .onSizeChanged { size ->
                    areaW = size.width.toFloat()
                    areaH = size.height.toFloat()
                }
                .pointerInput(running, radiusPx) {
                    detectTapGestures { offset ->
                        if (running) {
                            val dx = offset.x - targetX
                            val dy = offset.y - targetY
                            if (sqrt(dx * dx + dy * dy) <= radiusPx) {
                                hits += 1
                                Feedback.hit(context, settings.soundEnabled, settings.vibrationEnabled)
                                placeTargetRandomly()
                            } else {
                                misses += 1
                                Feedback.miss(context, settings.soundEnabled, settings.vibrationEnabled)
                            }
                        }
                    }
                },
            contentAlignment = Alignment.Center,
        ) {
            if (running) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawCircle(color = MilAmber, radius = radiusPx, center = Offset(targetX, targetY))
                    drawCircle(color = MilBg, radius = radiusPx * 0.25f, center = Offset(targetX, targetY))
                }
            } else {
                Text(
                    text = "Press Start, then tap the moving target.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MilMuted,
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(
                onClick = {
                    if (running) {
                        finishSession()
                    } else {
                        hits = 0
                        misses = 0
                        remaining = AIM_SECONDS
                        placeTargetRandomly()
                        running = true
                    }
                },
                modifier = Modifier.weight(1f),
            ) {
                Text(if (running) "Stop and save" else "Start")
            }
        }
    }
}
