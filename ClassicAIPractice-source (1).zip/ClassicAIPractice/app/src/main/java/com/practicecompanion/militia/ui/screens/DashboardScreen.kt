package com.practicecompanion.militia.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.practicecompanion.militia.Routes
import com.practicecompanion.militia.coach.LocalCoach
import com.practicecompanion.militia.data.PracticeRepository
import com.practicecompanion.militia.ui.components.AppBanner
import com.practicecompanion.militia.ui.components.SectionCard
import com.practicecompanion.militia.ui.components.StatTile
import com.practicecompanion.militia.ui.theme.MilBg
import com.practicecompanion.militia.ui.theme.MilMuted
import com.practicecompanion.militia.ui.theme.MilOlive
import com.practicecompanion.militia.ui.theme.MilSurface
import com.practicecompanion.militia.ui.theme.MilText

@Composable
fun DashboardScreen(repo: PracticeRepository, onNavigate: (String) -> Unit) {
    val history = repo.history
    val recommendations = remember(history) { LocalCoach.recommend(history) }
    val totalMinutes = history.sumOf { it.durationSec } / 60

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MilBg)
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(
            text = "CLASSIC AI PRACTICE",
            style = MaterialTheme.typography.headlineSmall,
            color = MilOlive,
            fontWeight = FontWeight.Bold,
        )
        Text(
            text = "Offline training companion",
            style = MaterialTheme.typography.bodyMedium,
            color = MilMuted,
        )

        AppBanner(
            "Unofficial companion app. Not affiliated with the makers of Mini Militia Classic. " +
                "It does not connect to, control, or add bots to the game."
        )

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile(label = "Sessions logged", value = history.size.toString(), modifier = Modifier.weight(1f))
            StatTile(label = "Minutes practiced", value = totalMinutes.toString(), modifier = Modifier.weight(1f))
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MilSurface),
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Training recommendations",
                    style = MaterialTheme.typography.titleMedium,
                    color = MilOlive,
                    fontWeight = FontWeight.Bold,
                )
                recommendations.forEach { rec ->
                    Text(
                        text = rec.title,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MilText,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                        text = rec.detail,
                        style = MaterialTheme.typography.bodySmall,
                        color = MilMuted,
                    )
                }
                Text(
                    text = "Rule-based suggestions from your local history only.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MilMuted,
                )
            }
        }

        SectionCard("Aim Training", "Moving targets in 30-second sessions") { onNavigate(Routes.AIM) }
        SectionCard("Reaction Training", "Measure your response time over five rounds") { onNavigate(Routes.REACTION) }
        SectionCard("Movement Training", "Timed drills you log yourself") { onNavigate(Routes.MOVEMENT) }
        SectionCard("Weapon Guides", "General tactics for choosing and using weapons") { onNavigate(Routes.WEAPONS) }
        SectionCard("Statistics", "Charts and history of your local sessions") { onNavigate(Routes.STATS) }
        SectionCard("Game Connection", "Check that Mini Militia Classic is installed and open it") {
            onNavigate(Routes.CONNECTION)
        }
        SectionCard("Settings", "Sound, vibration, language, and data") { onNavigate(Routes.SETTINGS) }
    }
}
